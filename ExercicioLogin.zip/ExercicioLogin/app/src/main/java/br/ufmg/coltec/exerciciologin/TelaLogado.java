package br.ufmg.coltec.exerciciologin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TelaLogado extends DebugActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_logado);
        Bundle activityBundle = this.getIntent().getExtras();
        String username = activityBundle.getCharSequence("usernome").toString();

        TextView seu_username = findViewById(R.id.seu_user);
        seu_username.setText("Seu username é " + username);

    }
}
