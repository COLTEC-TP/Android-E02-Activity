package br.ufmg.coltec.exerciciologin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TelaLogin extends DebugActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        final EditText user = findViewById(R.id.username);
        final EditText pwd = findViewById(R.id.pwd);
        Button btn = findViewById(R.id.login);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernome = user.getText().toString();
                String senha = pwd.getText().toString();

                if(usernome.equals("admin") && senha.equals("admin123")){
                    Intent intent = new Intent(TelaLogin.this, TelaLogado.class);
                    Log.i("Logado", "Usuário logou");
                    Bundle args = new Bundle();
                    args.putCharSequence("usernome", user.getText());
                    intent.putExtras(args);
                    startActivity(intent);


                }else if(usernome.equals("") || senha.equals("")){

                    Toast toast = Toast.makeText(TelaLogin.this, "Dados nulos", Toast.LENGTH_LONG);
                    toast.show();
                    Log.i("Não Logado", "Usuário não logou");

                } else{

                    Toast toast = Toast.makeText(TelaLogin.this, "Dados incorretos", Toast.LENGTH_LONG);
                    toast.show();
                    Log.i("Não Logado", "Usuário não logou");

                }

            }
        });

    }
}
