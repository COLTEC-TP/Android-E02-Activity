package br.ufmg.coltec.exerciciologin;


    import android.os.Bundle;
    import android.support.annotation.Nullable;
    import android.support.v7.app.AppCompatActivity;
    import android.util.Log;

/**
 * Created by a2016951782 on 07/03/18.
 */


    public class DebugActivity extends AppCompatActivity {
     @Override
     protected void onCreate(@Nullable Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    Log.i("OnCreate","OnCreate ON");
                }

             @Override
     protected void onResume() {
                    super.onResume();
                    Log.i("onResume","onResume ON");
                }

             @Override
     protected void onRestart() {
                    super.onRestart();
                    Log.i("OnRestart","onRestart ON");
                }

             @Override
     protected void onPause() {
                    super.onPause();
                    Log.i("onPause","onPause ON");
                }

             @Override
     protected void onStop() {
                    super.onStop();
                    Log.i("onStop","onStop ON");
                }

             @Override
            protected void onStart() {
                    super.onStart();
                   Log.i("onStart","onStart ON");
                }

}
