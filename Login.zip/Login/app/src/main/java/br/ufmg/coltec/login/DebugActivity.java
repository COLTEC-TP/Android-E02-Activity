package br.ufmg.coltec.login;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.style.SuperscriptSpan;
import android.util.Log;

public class DebugActivity extends AppCompatActivity{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        Log.i("onCreate", "Criado");
    }
    protected void onStart(){

        super.onStart();
        Log.i("onStart", "Start");
    }
    protected void onResume(){

        super.onResume();
        Log.i("onResume", "Interface exibida");
    }
    protected void onPause(){

        super.onPause();
        Log.i("onPause", "Pause");
    }
    protected void onStop(){

        super.onStop();
        Log.i("onStop", "Stop");
    }
    protected void onRestart(){

        super.onRestart();
        Log.i("onRestart", "Restart");
    }
    protected void onDestroy(){

        super.onDestroy();
        Log.i("onDestroy", "Destroy");
    }



}
