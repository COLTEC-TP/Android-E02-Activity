package br.ufmg.coltec.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Tela2 extends DebugActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        Bundle activityBundle = this.getIntent().getExtras();
        String name = activityBundle.getCharSequence("username").toString();

        TextView texto= findViewById(R.id.texto);
        texto.setText("Olá, usuario " + name);

    }
}
