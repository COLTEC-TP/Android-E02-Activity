package br.ufmg.coltec.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends DebugActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button botao = findViewById(R.id.button);
        final EditText username = findViewById(R.id.username);
        final EditText senha = findViewById(R.id.senha);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String password = senha.getText().toString();

                if (user.equals("admin") && password.equals("admin123")){
                    Log.i("tag", "Logou");
                    Intent tela2 = new Intent(MainActivity.this, Tela2.class);

                    Bundle args = new Bundle();
                    args.putCharSequence("username", username.getText());
                    tela2.putExtras(args);

                    startActivity(tela2);


                }
                else{
                    Toast.makeText(MainActivity.this, "Dados invalidos", Toast.LENGTH_SHORT).show();
                    Log.i("tag","Não Logou");
                }

            }
        });



    }
}
